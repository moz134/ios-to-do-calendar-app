//
//  TaskListHeader.swift
//  ios-to-do-calendar-app
//
//  Created by Md Mozammil on 19/01/23.
//

import UIKit

class TaskListHeader: UITableViewCell {

    @IBOutlet var headetTitleLbel: UILabel?
    @IBOutlet var greenView: UIView?
    override func awakeFromNib() {
        super.awakeFromNib()
        self.greenView?.layer.cornerRadius = (self.greenView?.frame.height ?? 20) / 2
    }
}
