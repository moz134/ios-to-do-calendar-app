//
//  Extensions.swift
//  ios-to-do-calendar-app
//
//  Created by Md Mozammil on 19/01/23.
//

import UIKit


extension UIView {
    func showShadow() {
        self.layer.masksToBounds = false
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.layer.shadowRadius = 2
        self.layer.shadowOpacity = 0.5
    }
}

extension UITextField {
    func setPlaceHolder(text: String) {
        let centeredParagraphStyle = NSMutableParagraphStyle()
        centeredParagraphStyle.alignment = .center
        self.attributedPlaceholder = NSAttributedString(
            string: text,
            attributes: [.paragraphStyle: centeredParagraphStyle]
        )
    }
}


extension String {
    func getCurrentDate() {
        let date = Date()
        let format = date.getFormattedDate(format: Constants.currentDateFormatter)
    }

    func getYearandMonth() -> (year: Int, month: Int) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = Constants.dateFormaterForMonth
        guard let date = dateFormatter.date(from: self) else {
            return (0, 0)
        }
        dateFormatter.dateFormat = "yyyy"
        let year = Int(dateFormatter.string(from: date)) ?? 2023
        dateFormatter.dateFormat = "MM"
        let month = Int(dateFormatter.string(from: date)) ?? 01
        return (year, month)
    }

    func getDayAndMonth() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = Constants.dateFormaterForMonth
        guard let date = dateFormatter.date(from: self) else {
            return ""
        }
        dateFormatter.dateFormat = "dd"
        let day = Int(dateFormatter.string(from: date))?.ordinal ?? ""
        dateFormatter.dateFormat = "MMM"
        let month = dateFormatter.string(from: date)
        return day + " " + month
    }
}

extension Date {
    func getFormattedDate(format: String) -> String {
        let dateformat = DateFormatter()
        dateformat.dateFormat = format
        return dateformat.string(from: self)
    }
}

extension Int {

    var ordinal: String {
        var suffix: String
        let ones: Int = self % 10
        let tens: Int = (self / 10) % 10
        if tens == 1 {
            // swiftlint:disable:next string_literal
            suffix = "th"
        } else if ones == 1 {
            // swiftlint:disable:next string_literal
            suffix = "st"
        } else if ones == 2 {
            // swiftlint:disable:next string_literal
            suffix = "nd"
        } else if ones == 3 {
            // swiftlint:disable:next string_literal
            suffix = "rd"
        } else {
            // swiftlint:disable:next string_literal
            suffix = "th"
        }
        // swiftlint:disable:next string_literal
        return "\(self)\(suffix)"
    }
}
