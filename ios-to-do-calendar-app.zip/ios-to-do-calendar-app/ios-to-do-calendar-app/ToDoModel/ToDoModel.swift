//
//  ToDoModel.swift
//  ios-to-do-calendar-app
//
//  Created by Md Mozammil on 19/01/23.
//

import Foundation

struct ToDoModel {
    
}
