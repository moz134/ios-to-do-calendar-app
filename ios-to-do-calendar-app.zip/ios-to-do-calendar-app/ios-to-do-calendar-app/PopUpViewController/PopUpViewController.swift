//
//  PopUpViewController.swift
//  ios-to-do-calendar-app
//
//  Created by Md Mozammil on 19/01/23.
//

import UIKit
import FSCalendar

class PopUpViewController: UIViewController, UITextFieldDelegate {


    @IBOutlet var backgroundButton: UIButton?

    @IBOutlet var contentView: UIView?

    @IBOutlet var titleLabel: UILabel?

    @IBOutlet var crossButton: UIButton?

    @IBOutlet var titleTextField: UITextField?
    @IBOutlet var dateTextField: UITextField?
    @IBOutlet var doneButton: UIButton?
    var delegate: DoneButtonAction?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUpUI()
    }

    func setUpUI() {
        self.titleTextField?.setPlaceHolder(text: "Enter Title")
        self.dateTextField?.setPlaceHolder(text: "Select Date")
        self.doneButton?.setTitle("Done", for: .normal)
        self.titleLabel?.text = "Add task"
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dateOpened))
        tapGesture.numberOfTapsRequired = 1
        self.dateTextField?.addGestureRecognizer(tapGesture)
        self.dateTextField?.delegate = self
    }

    @objc
    func dateOpened() {
        print("Date selected")
        let view = FSCalendar(frame: self.view.frame)
        self.view.addSubview(view)
        self.view.removeFromSuperview()
    }

    @IBAction func crossButtonAction(_ sender: Any) {
        self.view.removeFromSuperview()
    }
    @IBAction func backgroundBtnAction(_ sender: Any) {
        self.view.removeFromSuperview()
    }
    
    @IBAction func doneButtonAction(_ sender: Any) {
        var getExistingData = UserDefaults.standard.dictionary(forKey: "allEvents") as? [String: String] ?? [:]
        if !(dateTextField?.text?.isEmpty ?? true) && !(titleTextField?.text?.isEmpty ?? true) {
            getExistingData[dateTextField?.text ?? ""] = titleTextField?.text
            UserDefaults.standard.set(getExistingData, forKey: "allEvents")
            self.view.removeFromSuperview()
            self.delegate?.doneButton()
        }
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == self.dateTextField {
            return false
        }
        return true
    }
    
}
