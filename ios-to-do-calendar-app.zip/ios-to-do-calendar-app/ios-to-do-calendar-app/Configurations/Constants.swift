//
//  Constants.swift
//  ios-to-do-calendar-app
//
//  Created by Md Mozammil on 19/01/23.
//

import Foundation

class Constants {
    static let showToggleText = "Show Calendar"
    static let hideToggleText = "Hide Calendar"
    static let currentDateFormatter = "MMMM yyyy"
    static let dateFormaterForMonth = "yyyy-MM-dd"
}
