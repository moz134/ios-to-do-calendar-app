//
//  ToDoCalendarVC.swift
//  ios-to-do-calendar-app
//
//  Created by Md Mozammil on 19/01/23.
//

import UIKit
import FSCalendar

protocol DeleteButtonDelegate {
    func deleteButtonPressed(currentDate: String)
}
protocol DoneButtonAction {
    func doneButton()
}

class ToDoCalendarVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet var calendarView: FSCalendar?

    @IBOutlet var toggleCalendarBtn: UIButton?
    private var isCalendarToggle: Bool = false
    
    @IBOutlet var calenderViewHeightConstraint: NSLayoutConstraint?

    @IBOutlet weak var taskListTableView: UITableView?
    
    @IBOutlet var pastMonthView: UIView?
    
    @IBOutlet var futureMonthView: UIView?
    
    @IBOutlet var selectYearLabel: UILabel?

    private var allDatesOnly: [String] = []
    private var allEventsOnly: [String] = []
    private var currentDates: [String] = []
    private var currentEvent: [String] = []
    private var allDatesWithEvents: [String: String] = [:]
    private var currentDatesWithEvent: [String: String] = [:]
    private var selectedDate: String = ""

    fileprivate lazy var dateFormatter2: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = Constants.dateFormaterForMonth
        return formatter
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUpNavBar()
        self.calendarView?.delegate = self
        self.calendarView?.dataSource = self
        self.calendarView?.today = nil
        self.taskListTableView?.dataSource = self
        self.taskListTableView?.delegate = self
        let cellNib = UINib(nibName: "TaskListCellTableViewCell", bundle: nil)
        self.taskListTableView?.register(cellNib, forCellReuseIdentifier: "TaskListCellTableViewCell")
        let headerNib = UINib(nibName: "TaskListHeader", bundle: nil)
        self.taskListTableView?.register(headerNib, forCellReuseIdentifier: "TaskListHeader")
        self.setUpUI()
        fetchAllEvents()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.setCalendarHeight()
        reloadData()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.calendarView?.today = nil
    }

    func fetchAllEvents() {
        let datsa = UserDefaults.standard.dictionary(forKey: "allEvents") as? [String: String]
        self.allDatesOnly = datsa?.sorted(by: {$0.0 < $1.0 }).map({ $0.0 }) ?? []
        self.allEventsOnly = datsa?.sorted(by: {$0.0 < $1.0 }).map({ $0.1 }) ?? []
        let sortedDict = datsa?.sorted(by: {$0.0 < $1.0})
        var newDict: [String: String] = [:]
        for keyy in sortedDict ?? [] {
            newDict[keyy.key] = keyy.value
        }
        self.allDatesWithEvents = newDict
    }

    func setUpNavBar() {
        let rightNavButton = UIBarButtonItem(title: "+Add Task", style: .plain, target: self, action: #selector(addTask(sender: )))
        let leftNavButton = UIBarButtonItem(title: "To do List", style: .done, target: self, action: nil)
        leftNavButton.isEnabled = false
        self.navigationItem.rightBarButtonItem = rightNavButton
        self.navigationItem.leftBarButtonItem = leftNavButton
        self.navigationController?.navigationBar.isHidden = false
        self.navigationController?.isNavigationBarHidden = false

    }

    func setUpUI() {
        self.toggleCalendarBtn?.setTitle(Constants.showToggleText, for: .normal)
        self.calendarView?.isHidden = true
        self.pastMonthView?.showShadow()
        self.futureMonthView?.showShadow()
        let pastMonthGesture = UITapGestureRecognizer(target: self, action: #selector(pastMonth))
        self.pastMonthView?.addGestureRecognizer(pastMonthGesture)
        let futureMonthGesture =  UITapGestureRecognizer(target: self, action: #selector(showFutureMonth))
        self.futureMonthView?.addGestureRecognizer(futureMonthGesture)

        let date = Date()
        let format = date.getFormattedDate(format: Constants.currentDateFormatter)

        self.selectYearLabel?.text = format
        let selectYearGesture =  UITapGestureRecognizer(target: self, action: #selector(showFutureMonth))
        self.selectYearLabel?.isUserInteractionEnabled = true
        selectYearLabel?.addGestureRecognizer(selectYearGesture)
    }

    @objc
    func pastMonth() {
        print("Past month clicked")
        calendarView?.setCurrentPage(getPreviousMonth(date: calendarView?.currentPage ?? Date()), animated: true)
    }

    @objc
    func showFutureMonth() {
        print("Future month clicked")
        calendarView?.setCurrentPage(getNextMonth(date: calendarView?.currentPage ?? Date()), animated: true)
    }

    @objc
    func selectYear() {
        
    }

    func setCalendarHeight() {
        if isCalendarToggle {
            self.calenderViewHeightConstraint?.constant = CGFloat(300)
        } else {
            self.calenderViewHeightConstraint?.constant = CGFloat(0.0)
            self.calendarView?.isHidden = true
        }
    }

    @objc
    func addTask(sender: Any) {
        let popVC = PopUpViewController()
        self.addChild(popVC)
        popVC.view.frame = self.view.frame
        self.view.addSubview(popVC.view)
        popVC.dateTextField?.text = sender as? String
        popVC.delegate = self
        popVC.didMove(toParent: self)
    }

    
    @IBAction func toggleCalendarAction(_ sender: UIButton) {
        isCalendarToggle = !isCalendarToggle
        if sender.currentTitle == Constants.showToggleText {
            self.toggleCalendarBtn?.setTitle(Constants.hideToggleText, for: .normal)
            self.calendarView?.isHidden = false
            setCalendarHeight()
        } else {
            self.toggleCalendarBtn?.setTitle(Constants.showToggleText, for: .normal)
            self.calendarView?.isHidden = true
            setCalendarHeight()
        }

    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.currentDates.count + 1
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let header = taskListTableView?.dequeueReusableCell(withIdentifier: "TaskListHeader", for: indexPath) as? TaskListHeader
            header?.headetTitleLbel?.text = "Task list"
            header?.selectionStyle = UITableViewCell.SelectionStyle.none
            return header ?? UITableViewCell()
        } else {
            let cell = taskListTableView?.dequeueReusableCell(withIdentifier: "TaskListCellTableViewCell") as? TaskListCellTableViewCell
            cell?.dateLabel?.text = self.currentEvent[indexPath.row-1]
            cell?.taskTitleLabel?.text = self.currentDates[indexPath.row-1].getDayAndMonth()
            cell?.selectionStyle = UITableViewCell.SelectionStyle.none
            cell?.delegate = self
            cell?.currentDate = self.currentDates[indexPath.row-1]
            return cell ?? UITableViewCell()
        }
    }

    func reloadData() {
        self.getCurrentValues(year: Calendar.current.dateComponents([.month, .year], from: self.calendarView?.currentPage ?? FSCalendar().currentPage))
        self.fetchAllEvents()
        self.calendarView?.reloadData()
        self.taskListTableView?.reloadData()
    }
}


extension ToDoCalendarVC: FSCalendarDelegate, FSCalendarDataSource, FSCalendarDelegateAppearance {

    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        print(date)
        self.addTask(sender: date.getFormattedDate(format: Constants.dateFormaterForMonth))
    }

    func calendar(_ calendar: FSCalendar, shouldSelect date: Date, at monthPosition: FSCalendarMonthPosition) -> Bool {
        if date.compare(Date()) == .orderedAscending {
            let filterData = self.allDatesOnly.filter( { $0 == date.getFormattedDate(format: Constants.dateFormaterForMonth)})
            if filterData.isEmpty {
                return false
            } else {
                return true
            }
        }
        else {
            return true
        }
    }

    func getCurrentValues(year: DateComponents) {
        self.currentDatesWithEvent = self.allDatesWithEvents.filter({ $0.key.getYearandMonth().year == year.year && $0.key.getYearandMonth().month == year.month })

        self.currentDates = currentDatesWithEvent.sorted(by: {$0.0 < $1.0 }).map({ $0.0 })
        self.currentEvent = currentDatesWithEvent.sorted(by: {$0.0 < $1.0 }).map({ $0.1 })
    }
    func calendarCurrentPageDidChange(_ calendar: FSCalendar) {
        let currentPageDate = calendar.currentPage
        let month = Calendar.current.component(.month, from: currentPageDate)
        let year = Calendar.current.dateComponents([.month, .year], from: currentPageDate)
        let date = Calendar.current.component(.day, from: currentPageDate)
        let monthName = DateFormatter().monthSymbols[month - 1].capitalized
        self.getCurrentValues(year: year)
        let format = currentPageDate.getFormattedDate(format: Constants.currentDateFormatter)
        self.selectYearLabel?.text = format
        self.taskListTableView?.reloadData()
    }

    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, fillDefaultColorFor date: Date) -> UIColor? {
        let dateString = self.dateFormatter2.string(from: date)
        if self.allDatesOnly.contains(dateString) {
            return UIColor.brown
            }
        return UIColor.clear
    }

    func getNextMonth(date:Date) -> Date {
        return  Calendar.current.date(byAdding: .month, value: 1, to:date)!
    }

    func getPreviousMonth(date:Date) -> Date {
        return  Calendar.current.date(byAdding: .month, value: -1, to:date)!
    }
}

extension ToDoCalendarVC: DeleteButtonDelegate, DoneButtonAction {
    func deleteButtonPressed(currentDate: String) {
        let filter = self.allDatesWithEvents.filter( { $0.0 != currentDate })
        UserDefaults.standard.set(filter, forKey: "allEvents")
        self.fetchAllEvents()
        let year = Calendar.current.dateComponents([.month, .year], from: self.calendarView?.currentPage ?? FSCalendar().currentPage)
        self.getCurrentValues(year: year)
        self.reloadData()
    }
    func doneButton() {
        self.reloadData()
    }
}
