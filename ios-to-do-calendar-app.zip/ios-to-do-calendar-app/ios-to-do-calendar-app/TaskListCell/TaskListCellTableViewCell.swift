//
//  TaskListCellTableViewCell.swift
//  ios-to-do-calendar-app
//
//  Created by Md Mozammil on 19/01/23.
//

import UIKit

class TaskListCellTableViewCell: UITableViewCell {


    @IBOutlet var taskTitleLabel: UILabel?
    
    @IBOutlet var dateLabel: UILabel?
    
    @IBOutlet var deleteButton: UIButton?
    var delegate: DeleteButtonDelegate?
    var currentDate: String = ""

    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    @IBAction func deleteButtonAction(_ sender: Any) {
        print("delete button pressed")
        self.delegate?.deleteButtonPressed(currentDate: self.currentDate)
    }
}
